package CheckProfile.TestOfflineProfile;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.googlecode.junittoolbox.SuiteClasses;
import com.jayway.restassured.response.Response;
import io.qameta.allure.Feature;
import io.qameta.allure.Story;
import org.junit.runner.RunWith;
import org.testng.annotations.Test;

import java.io.FileWriter;
import java.io.IOException;

import static CheckProfile.GeneralData.AllParameters.EndPoints.*;
import static CheckProfile.TestOnlineProfile.JsonBody.sendTrueBody.createNewOfflineOrder;
import static com.jayway.restassured.RestAssured.expect;
import static org.assertj.core.api.Java6Assertions.assertThat;

@Feature("Проверка отправляемых данных в Оффлайне анкете и сохранение их в БД")
public class TestSendProfile1 {

    @Test
    @Story("Создаём новый заказ в Мвидео")
    public void createNewOfflineOrder() throws IOException{
        FileWriter fileWriterNumberOrder = new FileWriter("numberOfflineOrder.txt");
        fileWriterNumberOrder.write(numberOffline);
        fileWriterNumberOrder.close();
        Response response = expect()
                .statusCode(200)
                .given()
                .header("cache-control", cachControl)
                .cookie(getPhpSessId)
                .contentType(JSON)
                .body(createNewOfflineOrder)
                .when()
                .post(createOfflineOrder);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo("true");
        result = jsonObject.get("order_number").getAsString();
        assertThat(result).isEqualTo(getNumberOfflineOrderOfFile());
        String order_id = jsonObject.get("order_id").getAsString();
        FileWriter fileWriter = new FileWriter("orderIdOffline.txt");
        fileWriter.write(order_id);
        fileWriter.close();
    }
}
