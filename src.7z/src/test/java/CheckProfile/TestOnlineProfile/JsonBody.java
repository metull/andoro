package CheckProfile.TestOnlineProfile;

import java.io.IOException;

import static CheckProfile.GeneralData.AllParameters.EndPoints.*;
import static CheckProfile.GeneralData.Data.manyRandomSimbols;
import static CheckProfile.GeneralData.Data.sendManyRandomSimbols;
import static CheckProfile.GeneralData.SetterAndGetter.*;

public class JsonBody {
    //            Положительные кейсы. Отправка запросов в нужной последовательности и верными параметрами.
    public static class sendTrueBody {


        public static String bodyCreatNewOdder;

        static {
            try {
                bodyCreatNewOdder = "" +
                        "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ord=\"http://dcsoap.direct-credit.ru/orders\">" +
                        "   <soapenv:Header/>" +
                        "   <soapenv:Body>" +
                        "      <ord:createOrder>" +
                        "         <ord:data>" +
                        "            <ord:partnerID>340466701</ord:partnerID>" +
                        "            <ord:order>numberOrder" + getNumberOrderOfFile() + "</ord:order>" +
                        "            <ord:codeTT>3</ord:codeTT>" +
                        "        </ord:data>" +
                        "     </ord:createOrder>" +
                        "   </soapenv:Body>" +
                        "</soapenv:Envelope>";
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public static String createNewOfflineOrder;

        static {
            try {
                createNewOfflineOrder = "{" +
                        "\"order\":{" +
                        "\"order_number\":\"" + getNumberOfflineOrderOfFile() + "\"," +
                        "\"outlet_store\":\"103421177\"" +
                        "}," +
                        "\"goods\":[{" +
                        "\"name\":\"ава\"," +
                        "\"type_of_goods_id\":\"4\"," +
                        "\"price\":\"12000\"," +
                        "\"quantity\":\"1\"" +
                        "}]" +
                        "}";
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        static String bodySms = "" +
                "{" +
                "\"phone_mobile\":\"(996) 960-2297\"," +
                "\"sms_code\":\"111111\"," +
                "\"ad_subscribe\":true" +
                "}";

        static String bodyAuth = "{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"phone\":{" +
                "\"phone_mobile\":\"(996) 960-2297\"" +
                "}" +
                "}";

        static String bodyCals = "{" +
                "\"loan_term\":10," +
                "\"down_payment\":10," +
                "\"loans\":[" +
                //Альфа банк
                "{" +
                "\"id\":\"116683705\"," +
                "\"bankId\":\"51824\"," +
                "\"services\":[" +
                "\"alfa_sms_service\"]," +
                "\"sms\":\"alfa_sms_service\"," +
                "\"insurances\":[false,false]," +
                "\"special\":false," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":false" +
                "}," +
                //РФБ банк
                "{" +
                "\"id\":\"204239713\"," +
                "\"bankId\":\"12236\"," +
                "\"services\":[\"rfb_sms_service_korpcentre\"]," +
                "\"sms\":\"rfb_sms_service_korpcentre\"," +
                "\"insurances\":[false,false]," +
                "\"special\":false,\"isPromo\":false," +
                "\"isAllowSmsSign\":false" +
                "}," +
                //Почта банк
                "{" +
                "\"id\":\"14846185\"," +
                "\"bankId\":\"376\"," +
                "\"services\":[]," +
                "\"sms\":false," +
                "\"insurances\":[false,false]," +
                "\"special\":false," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":false" +
                "}," +
                //Купи Не Копи
                "{" +
                "\"id\":\"384107763\"," +
                "\"bankId\":\"384091399\"," +
                "\"services\":[]," +
                "\"sms\":false," +
                "\"insurances\":[false,false]," +
                "\"special\":false," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":false" +
                "}," +
                //Тинькофф
                "{" +
                "\"id\":\"61859\"," +
                "\"bankId\":\"59113\"," +
                "\"services\":[\"tin_sms_service\"]," +
                "\"sms\":\"tin_sms_service\"," +
                "\"insurances\":[false,false]," +
                "\"special\":false," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":false" +
                "}," +
                //ОТП
                "{" +
                "\"id\":\"1806\"," +
                "\"bankId\":\"7\"," +
                "\"services\":[\"otp_sms_service\"]," +
                "\"sms\":\"otp_sms_service\"," +
                "\"insurances\":[false," +
                "\"work_mv_hkb_sms\"]," +
                "\"special\":false," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":false" +
                "}," +
                //Ренессанс
                "{" +
                "\"id\":\"83301633\"," +
                "\"bankId\":\"1\"," +
                "\"services\":[\"ren_sms_comfort\"]," +
                "\"sms\":\"ren_sms_comfort\"," +
                "\"insurances\":[false,false]," +
                "\"special\":false," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":false" +
                "}," +
                //ХКБ
                "{" +
                "\"id\":\"83529001\"," +
                "\"bankId\":\"8457\"," +
                "\"services\":[\"home_sms_service\"]," +
                "\"sms\":\"home_sms_service\"," +
                "\"insurances\":[false,\"work_mv_hkb_sms\"]," +
                "\"special\":{\"loan_term\":12," +
                "\"down_payment\":null" +
                "}," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":true" +
                "}," +
                //Рево
                "{" +
                "\"id\":\"336403881\"," +
                "\"bankId\":\"81039346\"," +
                "\"services\":[\"revo_sms_service\"]," +
                "\"sms\":\"revo_sms_service\"," +
                "\"insurances\":[false,false]," +
                "\"special\":{\"loan_term\":12," +
                "\"down_payment\":null" +
                "}," +
                "\"isPromo\":false," +
                "\"isAllowSmsSign\":true" +
                "}" +
                "]" +
                "}";

        static String fullBodyFromFirstStepProfile = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendSerialAndNumberPassportThroughSpace = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"2454 564 64\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String fullBodyFromNextStepProfile = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String fullBodyFromEndingStepProfile = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";
        static String sendSocialStatusrQrxbFSC = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"rQrxbFSC\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendSocialStatusDrBuzeAn = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"DrBuzeAn\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";
        static String sendSocialStatus1r8IYIt8 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"1r8IYIt8\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendSocialStatus0vxo1sNN = "{" +
                "\"social\":{" +
                "\"property_type_home\":\"SnQ0Vb2X\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"0vxo1sNN\"," +
                "\"costs\":12000," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":3," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_home\":\"(498) 465-12-31\"}," +
                "\"contact\":{" +
                "\"relation_degree\":\"mtsgrandchild\"," +
                "\"last_name_contact\":\"Галинин\"," +
                "\"name_contact\":\"Иван\"," +
                "\"second_name_contact\":\"Петрович\"," +
                "\"phone_contact\":\"(984) 615-6514\"" +
                "}" +
                "}";

        static String sendSocialStatusJ6VBpaeU = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"J6VBpaeU\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";
        static String sendSocialStatusKwt5ypR2 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"Kwt5ypR2\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";
        static String sendSocialStatusokcnc8te = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"okcnc8te\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";
        static String sendSocialStatusbX2QDLZE = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"bX2QDLZE\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";
        static String sendSocialStatuslhPLvIuA = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"lhPLvIuA\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";
        static String sendSocialStatusmtsip2 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"mtsip2\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendSocialStatusmtsowner = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"mtsowner\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendEducationiMX4K9nC = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"iMX4K9nC\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducation864JGulJ = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"864JGulJ\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducationjcolhX0Z = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"jcolhX0Z\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducationjjqjrJTK = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"jjqjrJTK\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducationtFQILYCv = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"tFQILYCv\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducation57Paul47 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"57Paul47\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducationAJZRN1S4 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"AJZRN1S4\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducation8IDMA3HA = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"8IDMA3HA\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String sendEducationnI429G0N = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"nI429G0N\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessType9JL0CJaJ = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"9JL0CJaJ\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeYbZ9AkwY = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"YbZ9AkwY\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeGYwOPZHc = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"GYwOPZHc\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypezfKLutAC = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"zfKLutAC\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypewqLuaWF5 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"wqLuaWF5\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTyperJ53DhFk = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"rJ53DhFk\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeTLnIGYrA = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"TLnIGYrA\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeMZHlWynW = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"MZHlWynW\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeT3eM0HYh = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"T3eM0HYh\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeMRDuHN8B = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"MRDuHN8B\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeRI4dVLx7 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"RI4dVLx7\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeqUvTRUyI = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"qUvTRUyI\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeSXSvcWC0 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"SXSvcWC0\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypebUvScCuH = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"bUvScCuH\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeg8sPMDIf = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"g8sPMDIf\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeYwy3KLwt = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"Ywy3KLwt\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeQdOlqnJy = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"QdOlqnJy\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeGBE8nNMU = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"GBE8nNMU\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessType7hOyZaSi = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"7hOyZaSi\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeV9SXT6aF = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"V9SXT6aF\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeSdvuwza2 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"Sdvuwza2\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTyper9v180sZ = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"r9v180sZ\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypegusuzCJ6 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"gusuzCJ6\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypexomrEYGH = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"xomrEYGH\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypespZgk3vs = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"spZgk3vs\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeURpGBtDS = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"URpGBtDS\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypekiZh51bJ = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"kiZh51bJ\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessType3CQJza5Y = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"3CQJza5Y\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypePmApfVXO = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"PmApfVXO\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeXrsTOwWt = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"XrsTOwWt\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeCFgxtHBa = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"CFgxtHBa\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeyi2BL42u = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"yi2BL42u\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypezp9P7jO8 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"zp9P7jO8\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypeLFKbshBl = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"LFKbshBl\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypemtschymistry = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"mtschymistry\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypemtsenergy = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"mtsenergy\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypemtsconstrmaterials = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"mtsconstrmaterials\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypemtslogistics2 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"mtslogistics2\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypemtsseo = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"mtsseo\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendBusinessTypemtsaudit = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"mtsaudit\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyTypeOBwD06es = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"OBwD06es\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyTypeZo8buZRw = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"Zo8buZRw\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyType73neHtC3 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"73neHtC3\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyType2f2ATRAL = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"2f2ATRAL\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyTypeikgSPiQC = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"ikgSPiQC\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyTypeuv4It78N = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"uv4It78N\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyTypeu6Ks36W0 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"u6Ks36W0\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyTypeSnQ0Vb2X = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"SnQ0Vb2X\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPropertyTypeYCOipzlk = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"YCOipzlk\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPositionTyperZ0E4mZP = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"rZ0E4mZP\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPositionTypeLdclPMjJ = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"LdclPMjJ\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPositionTypecEGMbybk = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"cEGMbybk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPositionTypenbzIyADA = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"nbzIyADA\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPositionTypemjwE1TnM = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"mjwE1TnM\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendPositionTypeau38D9bk = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendMaritalStatus5KvUof3u = "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"5KvUof3u\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"spouse\":{" +
                "\"spouse_startdate\":\"01.02.2010\"," +
                "\"spouse_last_name\":\"Федорова\"," +
                "\"spouse_first_name\":\"Ирина\"," +
                "\"spouse_second_name\":\"Степановна\"," +
                "\"phone_contact\":\"(987) 498-7684\"," +
                "\"spouse_birthday\":\"01.02.1975\"" +
                "}" +
                "}";

        static String sendMaritalStatusltS0HkZ6 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"ltS0HkZ6\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendMaritalStatusADoBCpAh = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"ADoBCpAh\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendMaritalStatusXCuGVp6h = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"XCuGVp6h\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendMaritalStatuspfQr7U3s = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"pfQr7U3s\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendMaritalStatus0LqzSuFm = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"0LqzSuFm\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRealEstateGZMHLndD = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"GZMHLndD\"," +
                "\"marital_status\":\"0LqzSuFm\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRealEstateOMeoKbkl = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"OMeoKbkl\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRealEstatergLt8p2r = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"rgLt8p2r\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRealEstate3NTeSzKj = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"3NTeSzKj\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRealEstateIHmTXb7L = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"IHmTXb7L\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRealEstateroommts = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"roommts\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegree7q9E0NKr = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"7q9E0NKr\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreeY1mQPKVz = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"Y1mQPKVz\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreeLnxmURg4 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"LnxmURg4\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreelR4v6uLT = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"lR4v6uLT\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreevDPgw1Q6 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"vDPgw1Q6\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreeC7ZMgbyc = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"C7ZMgbyc\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreeOVOxPkpx = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"OVOxPkpx\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreerDzqPVJr = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"rDzqPVJr\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreexKraP9DQ = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"xKraP9DQ\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegree0LilZJnc = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"0LilZJnc\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreeekYxqj5U = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"ekYxqj5U\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegree81dEVcZS = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"81dEVcZS\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreesDTKdM7Z = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"sDTKdM7Z\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreemtsgrandchild = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"mtsgrandchild\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendRelationDegreemtsgrandchild2 = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"" + getReal_estate() + "\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"au38D9bk\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"mtsgrandchild2\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String sendFullProfileWithTwoConact = "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":12520," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"ООО Русь Матушка\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\",\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":5," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"(999) 879-73-54\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"Y1mQPKVz\"," +
                "\"last_name_contact\":\"Васильев\"," +
                "\"name_contact\":\"Иван\"," +
                "\"second_name_contact\":\"Олегович\"," +
                "\"phone_contact\":\"(989) 865-5354\"" +
                "}," +
                "\"second_contact\":{" +
                "\"relation_degree_add\":\"mtsgrandchild2\"," +
                "\"last_name_contact_add\":\"Галинина\"," +
                "\"name_contact_add\":\"Ирина\"," +
                "\"second_name_contact_add\":\"Антоновна\"," +
                "\"phone_contact_add\":\"(925) 486-2548\"" +
                "}" +
                "}";
    }

    //            Отправка анкеты без заполнения полей
    static class sendWithoutField {

        //        Первый шаг анкеты  -------------------------------------------

        static String withoutLastName = "{" +
                "\"fio\":{" +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String withoutFirstName = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";
        static String withoutSecondName = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String withoutEmail = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":88888" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String withoutMonthlyIncome = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String withoutSex = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String withoutBirthday = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String withoutDataIssue = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"" +
                "}" +
                "}";

        //        Второй шаг анкеты  -------------------------------------------

        static String withoutSerialAndNumberPassport = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String withoutSubdivisionCode = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendSubdivisionCodeWith5Simbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"40003\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendSubdivisionCodeWithSimbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"40003" + manyRandomSimbols(1) + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";
        static String sendSubdivisionCodeWith7Simbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"4000323\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendIssuedPassportWith300Simbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + sendManyRandomSimbols(300) + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendIssuedPassportWithManySimbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + sendManyRandomSimbols(400) + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendIssuedPassportWithSimbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + sendManyRandomSimbols(300) + manyRandomSimbols(3) + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String withoutIssuedPassport = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String withoutBirthplace = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";


        static String sendBirthplaceWithManySimbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + sendManyRandomSimbols(179) + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendBirthplaceWithSimbols = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + sendManyRandomSimbols(176) + manyRandomSimbols(3) + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String withoutAddressReg = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"date_reg\":\"" + getDate_reg() + "\"," +
                "\"is_eq_reg\":\"1\"}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String withoutDataReg = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"is_eq_reg\":\"1\"" +
                "}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendDataRegTomorrow = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"" + getDateTomorrow() + "\"," +
                "\"is_eq_reg\":\"1\"" +
                "}," +
                "\"isDirtyPassportIssue\":false" +
                "}";

        static String sendDataRegBeforeBirthday = "{" +
                "\"address\":{" +
                "\"subdivision_code\":\"" + getSubdivision_code() + "\"," +
                "\"issued_passport\":\"" + getIssued_passport() + "\"," +
                "\"birthplace\":\"" + getBirthplace() + "\"," +
                "\"address_reg\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"date_reg\":\"31.01.1975\"," +
                "\"is_eq_reg\":\"1\"" +
                "}," +
                "\"isDirtyPassportIssue\":false" +
                "}";


        static String withoutPropertyTypeHome = "" +
                "{" +
                "\"social\":{" +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutMaritalStatus = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutChildren = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutSocialStatus = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutMotherLastName = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutCompanyName = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutBusinessType = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String withoutPositionType = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutWorkInLastPlaceYears = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":\"\"," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutWorkInLastPlaceMonth = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":\"\"," +
                "\"work_in_last_place_months\":\"\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String withoutPhoneWork = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";


        static String withoutRelationContact = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutLastNameContact = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutNameContact = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"" + getPhone_contact() + "\"" +
                "}" +
                "}";

        static String withoutPhoneContact = "" +
                "{" +
                "\"social\":{" +
                "\"property_type_home\":\"" + getProperty_type_home() + "\"," +
                "\"real_estate\":\"\"," +
                "\"marital_status\":\"" + getMarital_status() + "\"," +
                "\"children\":\"" + getChildren() + "\"," +
                "\"education\":\"" + getEducation() + "\"," +
                "\"social_status\":\"" + getSocial_status() + "\"," +
                "\"costs\":" + getCosts() + "," +
                "\"mother_last_name\":\"" + getMother_last_name() + "\"" +
                "}," +
                "\"work_data\":{" +
                "\"company_name\":\"" + getCompany_name() + "\"," +
                "\"address_work\":{" +
                "\"isManualSaved\":false," +
                "\"region\":\"г Москва\"," +
                "\"region_kladr\":\"7700000000000\"," +
                "\"district\":null," +
                "\"district_kladr\":null," +
                "\"city\":\"\"," +
                "\"city_kladr\":\"7700000000000\"," +
                "\"city_type\":\"\"," +
                "\"locality\":null," +
                "\"locality_kladr\":null," +
                "\"locality_type\":null," +
                "\"street\":\"Кибальчича\"," +
                "\"street_kladr\":\"77000000000146300\"," +
                "\"street_type\":\"ул\"," +
                "\"house\":\"1\"," +
                "\"house_kladr\":\"7700000000014630001\"," +
                "\"flat\":\"1\"," +
                "\"zip_code\":\"129164\"," +
                "\"kladr\":\"7700000000014630001\"," +
                "\"value\":\"г Москва, ул Кибальчича, д 1, кв 1\"," +
                "\"unrestricted_value\":\"г Москва, Алексеевский р-н, ул Кибальчича, д 1, кв 1\"" +
                "}," +
                "\"business_type\":\"" + getBusiness_type() + "\"," +
                "\"position_type\":\"" + getPosition_type() + "\"," +
                "\"work_in_last_place\":{" +
                "\"work_in_last_place_years\":" + getWork_in_last_place_years() + "," +
                "\"work_in_last_place_months\":\"" + getWork_in_last_place_months() + "\"" +
                "}," +
                "\"phone_work\":\"" + getPhone_work() + "\"" +
                "}," +
                "\"contact\":{" +
                "\"relation_degree\":\"" + getRelation_degree() + "\"," +
                "\"last_name_contact\":\"" + getLast_name_contact() + "\"," +
                "\"name_contact\":\"" + getName_contact() + "\"," +
                "\"second_name_contact\":\"" + getSecond_name_contact() + "\"," +
                "\"phone_contact\":\"\"" +
                "}" +
                "}";
    }

    //            Отправка анкеты с неверными значениями в полях
    static class sendWithBagValue {

//                Первый шаг анкеты

        static String sendInvalidSmsCode1 = "" +
                "{" +
                "\"phone_mobile\":\"(996) 960-2297\"," +
                "\"sms_code\":\"111112\"," +
                "\"ad_subscribe\":true" +
                "}";

        static String sendInvalidSmsCode2 = "" +
                "{" +
                "\"phone_mobile\":\"(996) 960-2297\"," +
                "\"sms_code\":\"11111\"," +
                "\"ad_subscribe\":true" +
                "}";

        static String sendInvalidSmsCode3 = "" +
                "{" +
                "\"phone_mobile\":\"(996) 960-2297\"," +
                "\"sms_code\":\"" + sendManyRandomSimbols(1) + "\"," +
                "\"ad_subscribe\":true" +
                "}";

        static String sendLastNameWithEnglishAlphabet = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "" + englishAlphabet + "1\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendFirstNameWithEnglishAlphabet = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "" + englishAlphabet + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendSecondNameWithEnglishAlphabet = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "" + englishAlphabet + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendEmailWithRussianAlphabet = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + russiaAlphabet + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendInvalidBirthday1 = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getNowDate() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendInvalidBirthday2 = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getDate100YearsLast() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendNormalDate = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendInvalidBirthday3 = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getDate100YearAnd1dayLast() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";
        static String sendInvalidBirthday4 = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getDate18YearsLast() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendInvalidBirthday5 = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getDate18YearsLastAnd1Day() + "\"," +
                "\"monthly_income\":" + getMonthly_income() + "," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendMaxPlusMonthlyIncome = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":9999999991," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";

        static String sendMinPlusMonthlyIncome = "{" +
                "\"fio\":{" +
                "\"last_name\":\"" + getLast_name() + "\"," +
                "\"first_name\":\"" + getFirst_name() + "\"," +
                "\"second_name\":\"" + getSecond_name() + "\"," +
                "\"sex\":\"" + getSex() + "\"," +
                "\"birthday\":\"" + getBirthday() + "\"," +
                "\"monthly_income\":999," +
                "\"email\":\"" + getEmail() + "\"" +
                "}," +
                "\"passport\":{" +
                "\"serial_number_passport\":\"" + getSerial_number_passport() + "\"," +
                "\"date_issue\":\"" + getDate_issue() + "\"" +
                "}" +
                "}";
    }
}

