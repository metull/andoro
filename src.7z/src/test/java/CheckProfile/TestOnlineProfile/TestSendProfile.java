package CheckProfile.TestOnlineProfile;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Story;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import org.json.JSONException;
import org.testng.annotations.Test;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;

import static CheckProfile.GeneralData.AllParameters.EndPoints.BasePath;
import static CheckProfile.GeneralData.AllParameters.EndPoints.JSON;
import static CheckProfile.GeneralData.AllParameters.EndPoints.authorization;
import static CheckProfile.GeneralData.AllParameters.EndPoints.cachControl;
import static CheckProfile.GeneralData.AllParameters.EndPoints.createNewOrder;
import static CheckProfile.GeneralData.AllParameters.EndPoints.get;
import static CheckProfile.GeneralData.AllParameters.EndPoints.getCustomerProfileIOfSQLRequest;
import static CheckProfile.GeneralData.AllParameters.EndPoints.getIdOrderOfFile;
import static CheckProfile.GeneralData.AllParameters.EndPoints.getNumberOrderOfFile;
import static CheckProfile.GeneralData.AllParameters.EndPoints.getSmsCode;
import static CheckProfile.GeneralData.AllParameters.EndPoints.getTokenOfFile;
import static CheckProfile.GeneralData.AllParameters.EndPoints.getValueOfTable;
import static CheckProfile.GeneralData.AllParameters.EndPoints.jsonObject;
import static CheckProfile.GeneralData.AllParameters.EndPoints.jsonOrderID;
import static CheckProfile.GeneralData.AllParameters.EndPoints.message;
import static CheckProfile.GeneralData.AllParameters.EndPoints.number;
import static CheckProfile.GeneralData.AllParameters.EndPoints.phpSessId;
import static CheckProfile.GeneralData.AllParameters.EndPoints.responseBody;
import static CheckProfile.GeneralData.AllParameters.EndPoints.result;
import static CheckProfile.GeneralData.AllParameters.EndPoints.send;
import static CheckProfile.GeneralData.AllParameters.EndPoints.type;
import static CheckProfile.GeneralData.AllParameters.EndPoints.valueFalse;
import static CheckProfile.GeneralData.AllParameters.EndPoints.valueTrue;
import static CheckProfile.GeneralData.AllParameters.EndPoints.zero;
import static CheckProfile.GeneralData.SetterAndGetter.*;
import static CheckProfile.GeneralData.SqlRequest.getValueOfTable;
import static CheckProfile.TestOnlineProfile.JsonBody.sendTrueBody.*;
import static CheckProfile.TestOnlineProfile.JsonBody.sendWithBagValue.*;
import static CheckProfile.TestOnlineProfile.JsonBody.sendWithoutField.*;
import static com.jayway.restassured.RestAssured.expect;
import static org.assertj.core.api.Java6Assertions.assertThat;

//import static CheckProfile.GeneralData.SqlRequest.*;


@Epic("Проверка отправляемых данных в Онлайн анкете и сохранение их в БД")
public class TestSendProfile {

    @Test
    @Story("Создаём заказ в Онлайне")
    @Description("Создание заказа")
    public void createNewOrder() throws SQLException, IOException {
        FileWriter fileWriterNumberOrder = new FileWriter("numberOrder.txt");
        fileWriterNumberOrder.write(number);
        fileWriterNumberOrder.close();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("authorization", authorization)
                        .header("content-type", type)
                        .header("cache-control", cachControl)
                        .contentType("text/xml; charset=UTF-8")
                        .body(bodyCreatNewOdder)
                        .when()
                        .post(createNewOrder);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        FileWriter writer = new FileWriter("notes3.xml", false);
        String text = responseBody;
        writer.write(text);
        writer.close();

        String idOrder = getValueOfTable("select id from dc_order where order_number = " + "\"numberOrder" + getNumberOrderOfFile() + "\";");
        FileWriter fileWriterIDOrder = new FileWriter("idOrder.txt");
        fileWriterIDOrder.write(idOrder);
        fileWriterIDOrder.close();
    }

    @Test(dependsOnMethods = "createNewOrder")
    @Story("Запрашиваем СМС-код")
    public void getSmsCode() throws IOException {
        send = getSmsCode + getIdOrderOfFile();
        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(send)
                .build();
        okhttp3.Response response = okHttpClient.newCall(request).execute();
        System.out.println(response.body().string());
    }

    @Test(dependsOnMethods = "getSmsCode")
    @Story("Отправляем проверочный СМС-код")
    public void sendSmsCode() throws IOException {
        send = BasePath + "sms/check&token=" + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(bodySms)
                        .when()
                        .post(send);
        String responseBody = response.getBody().asString();
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        System.out.println(responseBody);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueTrue);
        String token = jsonObject.get("sms_code").getAsString();
        FileWriter fileWriter = new FileWriter("token.txt");
        fileWriter.write(token);
        fileWriter.close();
    }

    @Test(dependsOnMethods = "getSmsCode")
    @Story("Отправка неверного СМС-кода")
    public void sendInvalidSmsCode1() throws IOException {
        send = BasePath + "sms/check&token=" + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidSmsCode1)
                        .when()
                        .post(send);
        String responseBody = response.getBody().asString();
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        System.out.println(responseBody);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueFalse);
        String token = jsonObject.get("message").getAsString();
        assertThat(token).isEqualTo("Неверный код.");
    }

    @Test(dependsOnMethods = "getSmsCode")
    @Story("Отправка СМС-кода из 5 цифр")
    public void sendInvalidSmsCode2() throws IOException {
        send = BasePath + "sms/check&token=" + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidSmsCode2)
                        .when()
                        .post(send);
        String responseBody = response.getBody().asString();
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        System.out.println(responseBody);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueFalse);
        String token = jsonObject.get("message").getAsString();
        assertThat(token).isEqualTo("Неверный код.");
    }

    @Test(dependsOnMethods = "getSmsCode")
    @Story("Отправка СМС-кода с добавлением символов")
    public void sendInvalidSmsCode3() throws IOException {
        send = BasePath + "sms/check&token=" + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidSmsCode3)
                        .when()
                        .post(send);
        String responseBody = response.getBody().asString();
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        System.out.println(responseBody);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueFalse);
        String token = jsonObject.get("message").getAsString();
        assertThat(token).isEqualTo("Неверный код.");
    }

    @Test(dependsOnMethods = "sendInvalidSmsCode3")
    @Story("Осталось 2 попытки")
    @Description("Отправка СМС-кода")
    public void sendInvalidSmsCodeLast2Chance() throws IOException {
        send = BasePath + "sms/check&token=" + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidSmsCode3)
                        .when()
                        .post(send);
        String responseBody = response.getBody().asString();
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        System.out.println(responseBody);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueFalse);
        String token = jsonObject.get("message").getAsString();
        assertThat(token).isEqualTo("Неверный код. У Вас осталось 2 попытки");
    }

    @Test(dependsOnMethods = "sendInvalidSmsCodeLast2Chance")
    @Story("Осталось 1 попытка")
    @Description("Отправка СМС-кода")
    public void sendInvalidSmsCodeLast1Chance() throws IOException {
        send = BasePath + "sms/check&token=" + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidSmsCode3)
                        .when()
                        .post(send);
        String responseBody = response.getBody().asString();
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        System.out.println(responseBody);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueFalse);
        String token = jsonObject.get("message").getAsString();
        assertThat(token).isEqualTo("Неверный код. У Вас осталась 1 попытка");
    }

    @Test(dependsOnMethods = "sendInvalidSmsCodeLast1Chance")
    @Story("Использованы все попытки проверки кода.")
    @Description("Отправка СМС-кода")
    public void sendInvalidSmsCodeLastNoMoreAttempts() throws IOException {
        send = BasePath + "sms/check&token=" + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidSmsCode3)
                        .when()
                        .post(send);
        String responseBody = response.getBody().asString();
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        System.out.println(responseBody);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueFalse);
        String token = jsonObject.get("message").getAsString();
        assertThat(token).isEqualTo("Использованы все попытки проверки кода. Продолжение оформления заказа невозможно.");

    }

    @Test(dependsOnMethods = "sendSmsCode")
    @Story("Отправляем запрос на авторизацию")
    @Description("Получаем ookies - PHPSESSID")
    public void sendAuth() throws IOException, SQLException {
        send = BasePath + "auth/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(bodyAuth)
                        .when()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        assertThat(responseBody).isEqualTo("null");
    }

    @Test(dependsOnMethods = "sendAuth")
    @Story("Отправляем данные калькулятора")
    public void calculator() throws IOException {
        send = BasePath + "calc/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect().statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(bodyCals)
                        .when()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        result = jsonObject.get("result").getAsString();
        assertThat(result).isEqualTo(valueTrue);
        String getOrderId = jsonObject.get("order_id").getAsString();
        assertThat(getOrderId).isEqualTo("" + getIdOrderOfFile());
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Фамилию")
    @Description("Отправляем не полный Json")
    public void withoutLastName() throws IOException {
        send = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutLastName)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Фамилия : Поле не должно быть пустым");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Имя")
    @Description("Отправляем не полный Json")
    public void withoutFirstName() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutFirstName)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Имя : Поле не должно быть пустым");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Отчество.")
    @Description("Отправляем не полный Json. Поле не обязательно для заполнения")
    public void withoutSecondName() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutSecondName)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("2");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Дата рождения")
    @Description("Отправляем не полный Json.")
    public void withoutBirthday() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutBirthday)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата рождения : This is not date, Дата выдачи : Одно из полей должно содержать данные.");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Email")
    @Description("Отправляем не полный Json.")
    public void withoutEmail() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutEmail)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Электронная почта : Поле не должно быть пустым");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Ежемесячный доход")
    @Description("Отправляем не полный Json.")
    public void withoutMonthlyIncome() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutMonthlyIncome)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Ежемесячный доход : Поле не должно быть пустым, Значение должно быть больше 999");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Пол")
    @Description("Отправляем не полный Json.")
    public void withoutSex() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutSex)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Пол: : Поле не должно быть пустым");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не заполняем Дата выдачи")
    @Description("Отправляем не полный Json.")
    public void withoutDataIssue() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutDataIssue)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата выдачи : Поле не должно быть пустым");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Отправка серии и номера паспорта через пробел")
    @Description("Отправляем невалидный Json.")
    public void sendSerialAndNumberPassportThroughSpace() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSerialAndNumberPassportThroughSpace)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Серия и номер паспорта : Формат поля неверный.");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Не отправляем паспорт")
    @Description("Отправляем не полный Json.")
    public void withoutSerialAndNumberPassport() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutSerialAndNumberPassport)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Серия и номер паспорта : Поле не должно быть пустым");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Добавляем английский алфавит в Фамилию")
    @Description("Отправляем невалидный Json.")
    public void sendLastNameWithEnglishAlphabet() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendLastNameWithEnglishAlphabet)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Фамилия : Формат поля неверный.");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Добавляем английский алфавит в Имя")
    @Description("Отправляем невалидный Json.")
    public void sendFirstNameWithEnglishAlphabet() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendFirstNameWithEnglishAlphabet)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Имя : Формат поля неверный.");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator", description = "Добавляем английский алфавит в Отчество")
    @Story("Добавляем английский алфавит в Отчество")
    @Description("Отправляем невалидный Json.")
    public void sendSecondNameWithEnglishAlphabet() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSecondNameWithEnglishAlphabet)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Отчество : Формат поля неверный.");
    }

    @Test(dependsOnMethods = "calculator")
    @Story("Добавляем Русского алфавита в Email")
    @Description("Отправляем невалидный Json.")
    public void sendEmailWithRussianAlphabet() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEmailWithRussianAlphabet)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Электронная почта : Формат поля неверный.");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Отправляем сегодняшнюю дату рождения")
    @Description("Отправляем невалидный Json.")
    public void sendInvalidBirthday1() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidBirthday1)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата рождения : Дата не входит в диапазон, Дата выдачи : Одно из полей должно содержать данные.");
    }

    @Test(groups = "firstStepProfile", dependsOnGroups = "nexStepProfile")
    @Story("Отправляем дату рождения 100 лет назад")
    @Description("Отправляем невалидный Json.")
    public void sendInvalidBirthday2() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidBirthday2)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("navigated").getAsString();
        assertThat(message).isEqualTo("2");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "sendInvalidBirthday2")
    @Story("Отправляем пригодную дату рождения")
    @Description("Отправляем валидный Json.")
    public void sendNormalDate() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendNormalDate)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("navigated").getAsString();
        assertThat(message).isEqualTo("2");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Отправляем 100 лет и 1 день")
    @Description("Отправляем невалидный Json.")
    public void sendInvalidBirthday3() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidBirthday3)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата рождения : Дата не входит в диапазон");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Отправляем дату рождения 18 лет назад")
    @Description("Отправляем невалидный Json.")
    public void sendInvalidBirthday4() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidBirthday4)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата выдачи : Одно из полей должно содержать данные.");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Завтра исполнится 18")
    @Description("Отправляем невалидный Json.")
    public void sendInvalidBirthday5() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendInvalidBirthday5)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата рождения : Дата не входит в диапазон, Дата выдачи : Одно из полей должно содержать данные.");
    }

    @Test(dependsOnMethods = "calculator")
    @Story("Отправляем превышение месячного дохода")
    @Description("Отправляем невалидный Json.")
    public void sendMaxPlusMonthlyIncome() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMaxPlusMonthlyIncome)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("превышение месячного дохода 9999999991");
    }

    @Test(groups = "firstStepProfile", dependsOnMethods = "calculator")
    @Story("Отправляем сумму меньше месячного дохода")
    @Description("Отправляем невалидный Json.")
    public void sendMinMonthlyIncome() throws IOException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMinPlusMonthlyIncome)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Ежемесячный доход : Значение должно быть больше 999");
    }

    @Test(dependsOnMethods = "sendAuth")
    @Story("Отправка всех полей СК анкеты")
    @Description("Отправляем валидный Json. Переходим ко 2 шагу анкеты")
    public void sendStep1() throws IOException, SQLException {
        String sendStep1 = BasePath + "step1/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(fullBodyFromFirstStepProfile)
                        .log().ifValidationFails()
                        .post(sendStep1);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("2");

        getValueOfTable = getValueOfTable("select " + getLastNameBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getLast_name()).isEqualTo(getValueOfTable);
        System.out.println(getLast_name());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getFirstNameBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getFirst_name()).isEqualTo(getValueOfTable);
        System.out.println(getFirst_name());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getSecondNameBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getSecond_name()).isEqualTo(getValueOfTable);
        System.out.println(getSecond_name());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getSexBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getSex()).isEqualTo(getValueOfTable);
        System.out.println(getSex());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getBirthdayBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("1975-02-01 00:00:00").isEqualTo(getValueOfTable);
        System.out.println("1975-02-01 00:00:00");
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getMonthlyIncomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getMonthly_income() + ".0000").isEqualTo(getValueOfTable);
        System.out.println(getMonthly_income() + ".0000");
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getEmailBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getEmail()).isEqualTo(getValueOfTable);
        System.out.println(getEmail());
        System.out.println(getValueOfTable);

        String serial = getValueOfTable("select " + getSerialPassportBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        String number = getValueOfTable("select " + getNumberPassportBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getSerial_number_passport()).isEqualTo(serial + " " + number);
        System.out.println(getSerial_number_passport());
        System.out.println(serial + " " + number);

        getValueOfTable = getValueOfTable("select " + getDateIssuedBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("2010-02-01 00:00:00").isEqualTo(getValueOfTable);
        System.out.println("2010-02-01 00:00:00");
        System.out.println(getValueOfTable);

    }

    @Test(groups = "nexStepProfile", dependsOnMethods = "sendStep1")
    @Story("Не заполняем Код подразделения")
    @Description("Отправляем невалидный Json.")
    public void withoutSubdivisionCode() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutSubdivisionCode)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Код подразделения : Поле не должно быть пустым");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем код подразделения из 5 цифр")
    @Description("Отправляем невалидный Json.")
    public void sendSubdivisionCodeWith5Simbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSubdivisionCodeWith5Simbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Код подразделения : Формат поля неверный., Колличество символов должно быть больше 6");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем символы в Код подразделения")
    @Description("Отправляем невалидный Json.")
    public void sendSubdivisionCodeWithSimbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSubdivisionCodeWithSimbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Код подразделения : Формат поля неверный., Колличество символов должно быть больше 6");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем код подразделения из 7 цифр")
    @Description("Отправляем невалидный Json.")
    public void sendSubdivisionCodeWith7Simbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSubdivisionCodeWith7Simbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Код подразделения : Формат поля неверный.");
    }

    @Test(groups = "nexStepProfile", dependsOnMethods = "sendStep1")
    @Story("Не заполняем Кем выдан")
    @Description("Отправляем невалидный Json.")
    public void withoutIssuedPassport() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutIssuedPassport)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Кем выдан : Поле не должно быть пустым");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем 300 символов в Кем выдан")
    @Description("Отправляем валидный Json.")
    public void sendIssuedPassportWith300Simbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendIssuedPassportWith300Simbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Кем выдан : Колличество символов не должно превышать 201");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем 400 символов в Кем выдан")
    @Description("Отправляем невалидный Json.")
    public void sendIssuedPassportWithManySimbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendIssuedPassportWithManySimbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Кем выдан : Колличество символов не должно превышать 201");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем символы в Кем выдан")
    @Description("Отправляем невалидный Json.")
    public void sendIssuedPassportWithSimbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendIssuedPassportWithSimbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Кем выдан : Формат поля неверный.");
    }

    @Test(groups = "nexStepProfile", dependsOnMethods = "sendStep1")
    @Story("Не заполняем Место рождения")
    @Description("Отправляем невалидный Json.")
    public void withoutBirthplace() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutBirthplace)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Место рождения : Поле не должно быть пустым");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем 179 символов в Место рождения")
    @Description("Отправляем валидный Json.")
    public void sendBirthplaceWithManySimbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBirthplaceWithManySimbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Место рождения : Колличество символов не должно превышать 121");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Отправляем символовы в Место рождения")
    @Description("Отправляем невалидный Json.")
    public void sendBirthplaceWithSimbols() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBirthplaceWithSimbols)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Место рождения : Формат поля неверный.,");
    }

    @Test(dependsOnMethods = "sendStep1")
    @Story("Не отправляем адресс регистрации")
    @Description("Отправляем невалидный Json.")
    public void withoutAddressReg() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutAddressReg)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Неверное описание! Адрес доставки договора должени быть в регионе Московская область");
    }

    @Test(groups = "nexStepProfile", dependsOnMethods = "sendStep1")
    @Story("Не заполняем Дата регистрации")
    @Description("Отправляем невалидный Json.")
    public void withoutDataReg() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutDataReg)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата регистрации : Поле не должно быть пустым");
    }

    @Test(groups = "nexStepProfile", dependsOnMethods = "sendStep1")
    @Story("Отправляем завтрашнюю дату в Дата регистрации")
    @Description("Отправляем невалидный Json.")
    public void sendDataRegTomorrow() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendDataRegTomorrow)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата регистрации : Дата не входит в диапазон");
    }

    @Test(groups = "nexStepProfile", dependsOnMethods = "sendStep1")
    @Story("Отправляем дату регистрации до даты рождения")
    @Description("Отправляем невалидный Json.")
    public void sendDataRegBeforeBirthday() throws IOException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendDataRegBeforeBirthday)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        message = jsonObject.get("message").getAsString();
        assertThat(message).isEqualTo("Дата регистрации : Дата не входит в диапазон");
    }

    @Test(dependsOnMethods = "sendInvalidBirthday2")
    @Story("Отправка всех полей К анкеты")
    @Description("Отправляем валидный Json. переходим на 3 шаг анкеты.")
    public void sendStep2() throws IOException, SQLException {
        String sendStep2 = BasePath + "step2/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(fullBodyFromNextStepProfile)
                        .log().ifValidationFails()
                        .post(sendStep2);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("3");

        getValueOfTable = getValueOfTable("select " + getSubdivisionCodeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getSubdivision_code()).isEqualTo(getValueOfTable);
        System.out.println(getSubdivision_code());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getIssuedPassportBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getIssued_passport()).isEqualTo(getValueOfTable);
        System.out.println(getIssued_passport());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getBirthplaceBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getBirthplace()).isEqualTo(getValueOfTable);
        System.out.println(getBirthplace());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getDateRegBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("2010-02-01 00:00:00").isEqualTo(getValueOfTable);
        System.out.println("2010-02-01 00:00:00");
        System.out.println(getValueOfTable);

    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Название организации")
    @Description("Отправляем невалидный Json.")
    public void withoutCompanyName() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutCompanyName)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Название организации : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Тип недвижимости по месту проживания")
    @Description("Отправляем невалидный Json.")
    public void withoutPropertyTypeHome() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutPropertyTypeHome)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Тип недвижимости по месту проживания : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Семейное положение")
    @Description("Отправляем невалидный Json.")
    public void withoutMaritalStatus() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutMaritalStatus)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Семейное положение : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем количество детей")
    @Description("Отправляем невалидный Json.")
    public void withoutChildren() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutChildren)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Социальный статус")
    @Description("Отправляем невалидный Json.")
    public void withoutSocialStatus() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutSocialStatus)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Социальный статус : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Девичья фамилия матери")
    @Description("Отправляем невалидный Json.")
    public void withoutMotherLastName() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutMotherLastName)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Девичья фамилия матери : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Вид деятельности")
    @Description("Отправляем невалидный Json.")
    public void withoutBusinessType() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutBusinessType)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Вид деятельности организации : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Тип Вашей должности")
    @Description("Отправляем невалидный Json.")
    public void withoutPositionType() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutPositionType)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Тип Вашей должности : Поле не должно быть пустым");
    }

    @Test(dependsOnMethods = "sendStep2")
    @Story("Не отправляем кол-во Лет на прошлом месте работы")
    @Description("Отправляем невалидный Json.")
    public void withoutWorkInLastPlaceYears() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutWorkInLastPlaceYears)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Лет : Значение должно быть не больше чем 26 лет и 2 месяцев, Значение не должно быть пустым, если поле Месяцев пусто, Месяцев : Значение не должно быть пустым, если поле Лет пусто");
    }

    @Test(dependsOnMethods = "sendStep2")
    @Story("Не отправляем количество месяцев на последнем месте работы")
    @Description("Отправляем невалидный Json.")
    public void withoutWorkInLastPlaceMonth() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutWorkInLastPlaceMonth)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Лет : Значение должно быть не больше чем 26 лет и 2 месяцев, Значение не должно быть пустым, если поле Месяцев пусто, Месяцев : Значение не должно быть пустым, если поле Лет пусто");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Рабочий телефон")
    @Description("Отправляем невалидный Json.")
    public void withoutPhoneWork() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutPhoneWork)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Рабочий телефон : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправлять Кем приходится контактное лицо")
    @Description("Отправляем невалидный Json.")
    public void withoutRelationContact() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutRelationContact)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Кем приходится контактное лицо : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Фамилия контактного лица")
    @Description("Отправляем невалидный Json.")
    public void withoutLastNameContact() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutLastNameContact)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Фамилия контактного лица : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Имя контактного лица")
    @Description("Отправляем невалидный Json.")
    public void withoutNameContact() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutNameContact)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Имя контактного лица : Поле не должно быть пустым");
    }

    @Test(groups = "finalSendProfile", dependsOnMethods = "sendStep2")
    @Story("Не отправляем Телефон контактного лица")
    @Description("Отправляем невалидный Json.")
    public void withoutPhoneContact() throws IOException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(withoutPhoneContact)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("message").getAsString();
        assertThat(navigated).isEqualTo("Телефон контактного лица : Поле не должно быть пустым");
    }

    @Test(dependsOnGroups = "finalSendProfile")
    @Story("Отправка всех полей Д анкеты")
    @Description("Отправляем валидный Json.")
    public void sendStep3() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(fullBodyFromEndingStepProfile)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getProperty_type_home()).isEqualTo(getValueOfTable);
        System.out.println(getProperty_type_home());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getMaritalStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getMarital_status()).isEqualTo(getValueOfTable);
        System.out.println(getMarital_status());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getChildrenBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getChildren() + zero).isEqualTo(getValueOfTable);
        System.out.println(getChildren() + zero);
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getEducation()).isEqualTo(getValueOfTable);
        System.out.println(getEducation());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getSocial_status()).isEqualTo(getValueOfTable);
        System.out.println(getSocial_status());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getCostsBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getCosts() + zero).isEqualTo(getValueOfTable);
        System.out.println(getCosts() + zero);
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getMotherLastNameBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getMother_last_name()).isEqualTo(getValueOfTable);
        System.out.println(getMother_last_name());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getCompanyNameBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getCompany_name()).isEqualTo(getValueOfTable);
        System.out.println(getCompany_name());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getBusiness_type()).isEqualTo(getValueOfTable);
        System.out.println(getBusiness_type());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getPositionTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getPosition_type()).isEqualTo(getValueOfTable);
        System.out.println(getPosition_type());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getPhoneWorkBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getPhone_work()).isEqualTo(getValueOfTable);
        System.out.println(getPhone_work());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getWorkInLastPlaceYearsBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("60.0000").isEqualTo(getValueOfTable);
        System.out.println("60.0000");
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getRelation_degree()).isEqualTo(getValueOfTable);
        System.out.println(getRelation_degree());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getLastNameContactBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getLast_name_contact()).isEqualTo(getValueOfTable);
        System.out.println(getLast_name_contact());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getNameContactBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getName_contact()).isEqualTo(getValueOfTable);
        System.out.println(getName_contact());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getSecondNameBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getSecond_name()).isEqualTo(getValueOfTable);
        System.out.println(getSecond_name());
        System.out.println(getValueOfTable);

        getValueOfTable = getValueOfTable("select " + getPhoneContactBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat(getPhone_contact()).isEqualTo(getValueOfTable);
        System.out.println(getPhone_contact());
        System.out.println(getValueOfTable);

    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Разнорабочий")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusrQrxbFSC() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusrQrxbFSC)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("rQrxbFSC").isEqualTo(getValueOfTable);
        System.out.println("rQrxbFSC");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Не работаю")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusDrBuzeAn() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusDrBuzeAn)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");
        get = BasePath + "step3/form" + jsonOrderID + getIdOrderOfFile() + "&token=" + getTokenOfFile();

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("DrBuzeAn").isEqualTo(getValueOfTable);
        System.out.println("DrBuzeAn");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Студент")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatus1r8IYIt8() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatus1r8IYIt8)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("1r8IYIt8").isEqualTo(getValueOfTable);
        System.out.println("1r8IYIt8");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Пенсионер")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatus0vxo1sNN() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatus0vxo1sNN)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("0vxo1sNN").isEqualTo(getValueOfTable);
        System.out.println("0vxo1sNN");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Домохозяйка")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusJ6VBpaeU() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusJ6VBpaeU)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("J6VBpaeU").isEqualTo(getValueOfTable);
        System.out.println("J6VBpaeU");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Коммерческий сотрудник")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusKwt5ypR2() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusKwt5ypR2)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("Kwt5ypR2").isEqualTo(getValueOfTable);
        System.out.println("Kwt5ypR2");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Предприниматель")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusokcnc8te() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusokcnc8te)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("okcnc8te").isEqualTo(getValueOfTable);
        System.out.println("okcnc8te");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Декретный отпуск")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusbX2QDLZE() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusbX2QDLZE)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("bX2QDLZE").isEqualTo(getValueOfTable);
        System.out.println("bX2QDLZE");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Государственный служащий")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatuslhPLvIuA() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatuslhPLvIuA)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("lhPLvIuA").isEqualTo(getValueOfTable);
        System.out.println("lhPLvIuA");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус ИП/Частная практика")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusmtsip2() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusmtsip2)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsip2").isEqualTo(getValueOfTable);
        System.out.println("mtsip2");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправляем соц статус Собственник/совладелец компании")
    @Description("Отправляем валидный Json.")
    public void sendSocialStatusmtsowner() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendSocialStatusmtsowner)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getSocialStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsowner").isEqualTo(getValueOfTable);
        System.out.println("mtsowner");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Нет")
    @Description("Отправляем валидный Json.")
    public void sendEducationiMX4K9nC() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducationiMX4K9nC)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("iMX4K9nC").isEqualTo(getValueOfTable);
        System.out.println("iMX4K9nC");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Начальное или незаконченное среднее")
    @Description("Отправляем валидный Json.")
    public void sendEducation864JGulJ() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducation864JGulJ)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("864JGulJ").isEqualTo(getValueOfTable);
        System.out.println("864JGulJ");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Среднее")
    @Description("Отправляем валидный Json.")
    public void sendEducationjcolhX0Z() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducationjcolhX0Z)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("jcolhX0Z").isEqualTo(getValueOfTable);
        System.out.println("jcolhX0Z");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Среднетехническое")
    @Description("Отправляем валидный Json.")
    public void sendEducationjjqjrJTK() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducationjjqjrJTK)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("jjqjrJTK").isEqualTo(getValueOfTable);
        System.out.println("jjqjrJTK");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Специальное техническое")
    @Description("Отправляем валидный Json.")
    public void sendEducationtFQILYCv() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducationtFQILYCv)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("tFQILYCv").isEqualTo(getValueOfTable);
        System.out.println("tFQILYCv");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Незаконченное высшее")
    @Description("Отправляем валидный Json.")
    public void sendEducation57Paul47() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducation57Paul47)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("57Paul47").isEqualTo(getValueOfTable);
        System.out.println("57Paul47");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Высшее")
    @Description("Отправляем валидный Json.")
    public void sendEducationAJZRN1S4() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducationAJZRN1S4)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("AJZRN1S4").isEqualTo(getValueOfTable);
        System.out.println("AJZRN1S4");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Второе высшее")
    @Description("Отправляем валидный Json.")
    public void sendEducation8IDMA3HA() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducation8IDMA3HA)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("8IDMA3HA").isEqualTo(getValueOfTable);
        System.out.println("8IDMA3HA");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка образования Степень")
    @Description("Отправляем валидный Json.")
    public void sendEducationnI429G0N() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendEducationnI429G0N)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getEducationBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("nI429G0N").isEqualTo(getValueOfTable);
        System.out.println("nI429G0N");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Бытовые услуги")
    @Description("Отправляем валидный Json.")
    public void sendBusinessType9JL0CJaJ() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessType9JL0CJaJ)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("9JL0CJaJ").isEqualTo(getValueOfTable);
        System.out.println("9JL0CJaJ");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Вооруженные силы")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeYbZ9AkwY() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeYbZ9AkwY)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("YbZ9AkwY").isEqualTo(getValueOfTable);
        System.out.println("YbZ9AkwY");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Гос.и муниципальные структуры")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeGYwOPZHc() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeGYwOPZHc)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("GYwOPZHc").isEqualTo(getValueOfTable);
        System.out.println("GYwOPZHc");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Детективное, охранное предприятие")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypezfKLutAC() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypezfKLutAC)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("zfKLutAC").isEqualTo(getValueOfTable);
        System.out.println("zfKLutAC");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации ЖКХ")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypewqLuaWF5() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypewqLuaWF5)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("wqLuaWF5").isEqualTo(getValueOfTable);
        System.out.println("wqLuaWF5");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Здравоохранение")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTyperJ53DhFk() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTyperJ53DhFk)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("rJ53DhFk").isEqualTo(getValueOfTable);
        System.out.println("rJ53DhFk");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Издательская деятельность")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeTLnIGYrA() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeTLnIGYrA)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("TLnIGYrA").isEqualTo(getValueOfTable);
        System.out.println("TLnIGYrA");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Информационные технологии")
    public void sendBusinessTypeMZHlWynW() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeMZHlWynW)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("MZHlWynW").isEqualTo(getValueOfTable);
        System.out.println("MZHlWynW");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Легкая промышленность")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeT3eM0HYh() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeT3eM0HYh)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("T3eM0HYh").isEqualTo(getValueOfTable);
        System.out.println("T3eM0HYh");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Лесное хозяйство")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeMRDuHN8B() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeMRDuHN8B)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("MRDuHN8B").isEqualTo(getValueOfTable);
        System.out.println("MRDuHN8B");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Машиностроение, металлургия")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeRI4dVLx7() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeRI4dVLx7)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("RI4dVLx7").isEqualTo(getValueOfTable);
        System.out.println("RI4dVLx7");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Образование и наука")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeqUvTRUyI() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeqUvTRUyI)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("qUvTRUyI").isEqualTo(getValueOfTable);
        System.out.println("qUvTRUyI");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Оптовая торговля")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeSXSvcWC0() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeSXSvcWC0)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("SXSvcWC0").isEqualTo(getValueOfTable);
        System.out.println("SXSvcWC0");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Пищевая промышленность")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypebUvScCuH() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypebUvScCuH)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("bUvScCuH").isEqualTo(getValueOfTable);
        System.out.println("bUvScCuH");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Полиграфическая промышленность")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeg8sPMDIf() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeg8sPMDIf)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("g8sPMDIf").isEqualTo(getValueOfTable);
        System.out.println("g8sPMDIf");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Посредническая деятельность")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeYwy3KLwt() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeYwy3KLwt)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("Ywy3KLwt").isEqualTo(getValueOfTable);
        System.out.println("Ywy3KLwt");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Правоохранительные органы")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeQdOlqnJy() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeQdOlqnJy)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("QdOlqnJy").isEqualTo(getValueOfTable);
        System.out.println("QdOlqnJy");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Реклама, PR агентства, СМИ")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeGBE8nNMU() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeGBE8nNMU)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("GBE8nNMU").isEqualTo(getValueOfTable);
        System.out.println("GBE8nNMU");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Рестораны, кафе")
    @Description("Отправляем валидный Json.")
    public void sendBusinessType7hOyZaSi() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessType7hOyZaSi)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("7hOyZaSi").isEqualTo(getValueOfTable);
        System.out.println("7hOyZaSi");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Розничная торговля")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeV9SXT6aF() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeV9SXT6aF)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("V9SXT6aF").isEqualTo(getValueOfTable);
        System.out.println("V9SXT6aF");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Салоны красоты, фитнес-центры")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeSdvuwza2() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeSdvuwza2)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("Sdvuwza2").isEqualTo(getValueOfTable);
        System.out.println("Sdvuwza2");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Связь")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTyper9v180sZ() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTyper9v180sZ)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("r9v180sZ").isEqualTo(getValueOfTable);
        System.out.println("r9v180sZ");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Сельское хозяйство")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypegusuzCJ6() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypegusuzCJ6)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("gusuzCJ6").isEqualTo(getValueOfTable);
        System.out.println("gusuzCJ6");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Строительство, строительные материалы")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypexomrEYGH() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypexomrEYGH)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("xomrEYGH").isEqualTo(getValueOfTable);
        System.out.println("xomrEYGH");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Транспорт")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypespZgk3vs() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypespZgk3vs)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("spZgk3vs").isEqualTo(getValueOfTable);
        System.out.println("spZgk3vs");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации ТЭК, горнодобывающая промышленность")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeURpGBtDS() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeURpGBtDS)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("URpGBtDS").isEqualTo(getValueOfTable);
        System.out.println("URpGBtDS");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Увеселительный, шоу-бизнес, туризм")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypekiZh51bJ() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypekiZh51bJ)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("kiZh51bJ").isEqualTo(getValueOfTable);
        System.out.println("kiZh51bJ");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Финансы, банковское дело")
    @Description("Отправляем валидный Json.")
    public void sendBusinessType3CQJza5Y() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessType3CQJza5Y)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("3CQJza5Y").isEqualTo(getValueOfTable);
        System.out.println("3CQJza5Y");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Юридические услуги")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypePmApfVXO() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypePmApfVXO)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("PmApfVXO").isEqualTo(getValueOfTable);
        System.out.println("PmApfVXO");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Другое")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeXrsTOwWt() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeXrsTOwWt)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("XrsTOwWt").isEqualTo(getValueOfTable);
        System.out.println("XrsTOwWt");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Игорный бизнес")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeCFgxtHBa() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeCFgxtHBa)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("CFgxtHBa").isEqualTo(getValueOfTable);
        System.out.println("CFgxtHBa");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Страхование")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeyi2BL42u() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeyi2BL42u)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("yi2BL42u").isEqualTo(getValueOfTable);
        System.out.println("yi2BL42u");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Благотворительные и религиозные организации")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypezp9P7jO8() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypezp9P7jO8)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("zp9P7jO8").isEqualTo(getValueOfTable);
        System.out.println("zp9P7jO8");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Подбор персонала")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypeLFKbshBl() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypeLFKbshBl)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("LFKbshBl").isEqualTo(getValueOfTable);
        System.out.println("LFKbshBl");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Химия, парфюмерия, фармацевтика")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypemtschymistry() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypemtschymistry)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtschymistry").isEqualTo(getValueOfTable);
        System.out.println("mtschymistry");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Производство и распределение электроэнергии, газа, воды")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypemtsenergy() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypemtsenergy)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsenergy").isEqualTo(getValueOfTable);
        System.out.println("mtsenergy");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Производство строительных материалов")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypemtsconstrmaterials() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypemtsconstrmaterials)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsconstrmaterials").isEqualTo(getValueOfTable);
        System.out.println("mtsconstrmaterials");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Складское хранение и логистика")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypemtslogistics2() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypemtslogistics2)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtslogistics2").isEqualTo(getValueOfTable);
        System.out.println("mtslogistics2");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Операции с недвижимостью")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypemtsseo() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypemtsseo)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsseo").isEqualTo(getValueOfTable);
        System.out.println("mtsseo");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка вид деятельности организации Аудит, консталтинг")
    @Description("Отправляем валидный Json.")
    public void sendBusinessTypemtsaudit() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendBusinessTypemtsaudit)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getBusinessTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsaudit").isEqualTo(getValueOfTable);
        System.out.println("mtsaudit");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Собственность")
    @Description("Отправляем валидный Json.")
    public void sendPropertyTypeOBwD06es() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyTypeOBwD06es)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("OBwD06es").isEqualTo(getValueOfTable);
        System.out.println("OBwD06es");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Аренда")
    @Description("Отправляем валидный Json.")
    public void sendPropertyTypeZo8buZRw() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyTypeZo8buZRw)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("Zo8buZRw").isEqualTo(getValueOfTable);
        System.out.println("Zo8buZRw");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Проживаю у родственников")
    @Description("Отправляем валидный Json.")
    public void sendPropertyType73neHtC3() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyType73neHtC3)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("73neHtC3").isEqualTo(getValueOfTable);
        System.out.println("73neHtC3");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Предоставляется работодателем")
    @Description("Отправляем валидный Json.")
    public void sendPropertyType2f2ATRAL() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyType2f2ATRAL)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("2f2ATRAL").isEqualTo(getValueOfTable);
        System.out.println("2f2ATRAL");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Оплачено более 6 мес")
    @Description("Отправляем валидный Json.")
    public void sendPropertyTypeikgSPiQC() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyTypeikgSPiQC)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("ikgSPiQC").isEqualTo(getValueOfTable);
        System.out.println("ikgSPiQC");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Общежитие (Студент)")
    @Description("Отправляем валидный Json.")
    public void sendPropertyTypeuv4It78N() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyTypeuv4It78N)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("uv4It78N").isEqualTo(getValueOfTable);
        System.out.println("uv4It78N");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Собственность в залоге")
    @Description("Отправляем валидный Json.")
    public void sendPropertyTypeu6Ks36W0() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyTypeu6Ks36W0)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("u6Ks36W0").isEqualTo(getValueOfTable);
        System.out.println("u6Ks36W0");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Муниципальное жилье")
    @Description("Отправляем валидный Json.")
    public void sendPropertyTypeSnQ0Vb2X() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyTypeSnQ0Vb2X)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("SnQ0Vb2X").isEqualTo(getValueOfTable);
        System.out.println("SnQ0Vb2X");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Другое")
    @Description("Отправляем валидный Json.")
    public void sendPropertyTypeYCOipzlk() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPropertyTypeYCOipzlk)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPropertyTypeHomeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("YCOipzlk").isEqualTo(getValueOfTable);
        System.out.println("YCOipzlk");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Младший специалист")
    @Description("Отправляем валидный Json.")
    public void sendPositionTyperZ0E4mZP() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPositionTyperZ0E4mZP)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPositionTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("rZ0E4mZP").isEqualTo(getValueOfTable);
        System.out.println("rZ0E4mZP");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Специалист")
    @Description("Отправляем валидный Json.")
    public void sendPositionTypeLdclPMjJ() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPositionTypeLdclPMjJ)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPositionTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("LdclPMjJ").isEqualTo(getValueOfTable);
        System.out.println("LdclPMjJ");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Старший специалист")
    @Description("Отправляем валидный Json.")
    public void sendPositionTypecEGMbybk() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPositionTypecEGMbybk)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPositionTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("cEGMbybk").isEqualTo(getValueOfTable);
        System.out.println("cEGMbybk");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Начинающий руководитель")
    @Description("Отправляем валидный Json.")
    public void sendPositionTypenbzIyADA() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPositionTypenbzIyADA)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPositionTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("nbzIyADA").isEqualTo(getValueOfTable);
        System.out.println("nbzIyADA");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Руководитель с опытом")
    @Description("Отправляем валидный Json.")
    public void sendPositionTypemjwE1TnM() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPositionTypemjwE1TnM)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPositionTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mjwE1TnM").isEqualTo(getValueOfTable);
        System.out.println("mjwE1TnM");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Тип недвижимости по месту проживания Руководитель высшего звена")
    @Description("Отправляем валидный Json.")
    public void sendPositionTypeau38D9bk() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendPositionTypeau38D9bk)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getPositionTypeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("au38D9bk").isEqualTo(getValueOfTable);
        System.out.println("au38D9bk");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Семейное положение Женат/замужем")
    @Description("Отправляем валидный Json.")
    public void sendMaritalStatus5KvUof3u() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMaritalStatus5KvUof3u)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getMaritalStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("5KvUof3u").isEqualTo(getValueOfTable);
        System.out.println("5KvUof3u");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Семейное положение Холост/не замужем")
    @Description("Отправляем валидный Json.")
    public void sendMaritalStatusltS0HkZ6() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMaritalStatusltS0HkZ6)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getMaritalStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("ltS0HkZ6").isEqualTo(getValueOfTable);
        System.out.println("ltS0HkZ6");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Семейное положение Разведен/разведена")
    @Description("Отправляем валидный Json.")
    public void sendMaritalStatusADoBCpAh() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMaritalStatusADoBCpAh)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getMaritalStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("ADoBCpAh").isEqualTo(getValueOfTable);
        System.out.println("ADoBCpAh");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Семейное положение Раздельное проживание")
    @Description("Отправляем валидный Json.")
    public void sendMaritalStatusXCuGVp6h() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMaritalStatusXCuGVp6h)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getMaritalStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("XCuGVp6h").isEqualTo(getValueOfTable);
        System.out.println("XCuGVp6h");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Семейное положение Вдова/вдовец")
    @Description("Отправляем валидный Json.")
    public void sendMaritalStatuspfQr7U3s() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMaritalStatuspfQr7U3s)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getMaritalStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("pfQr7U3s").isEqualTo(getValueOfTable);
        System.out.println("pfQr7U3s");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка  Гражданский брак")
    @Description("Отправляем валидный Json.")
    public void sendMaritalStatus0LqzSuFm() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendMaritalStatus0LqzSuFm)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getMaritalStatusBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("0LqzSuFm").isEqualTo(getValueOfTable);
        System.out.println("0LqzSuFm");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка другая недвижимость Дача")
    @Description("Отправляем валидный Json.")
    public void sendRealEstateGZMHLndD() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRealEstateGZMHLndD)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRealEstateBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("GZMHLndD").isEqualTo(getValueOfTable);
        System.out.println("GZMHLndD");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка другая недвижимость Земельный участок")
    @Description("Отправляем валидный Json.")
    public void sendRealEstateOMeoKbkl() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRealEstateOMeoKbkl)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRealEstateBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("OMeoKbkl").isEqualTo(getValueOfTable);
        System.out.println("OMeoKbkl");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка другая недвижимость Гараж")
    @Description("Отправляем валидный Json.")
    public void sendRealEstatergLt8p2r() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRealEstatergLt8p2r)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRealEstateBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("rgLt8p2r").isEqualTo(getValueOfTable);
        System.out.println("rgLt8p2r");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка другая недвижимость Квартира")
    @Description("Отправляем валидный Json.")
    public void sendRealEstate3NTeSzKj() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRealEstate3NTeSzKj)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRealEstateBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("3NTeSzKj").isEqualTo(getValueOfTable);
        System.out.println("3NTeSzKj");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка другая недвижимость Другое")
    @Description("Отправляем валидный Json.")
    public void sendRealEstateIHmTXb7L() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRealEstateIHmTXb7L)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRealEstateBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("IHmTXb7L").isEqualTo(getValueOfTable);
        System.out.println("IHmTXb7L");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка другая недвижимость Комната")
    @Description("Отправляем валидный Json.")
    public void sendRealEstateroommts() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRealEstateroommts)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRealEstateBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("roommts").isEqualTo(getValueOfTable);
        System.out.println("roommts");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Бабушка")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegree7q9E0NKr() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegree7q9E0NKr)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("7q9E0NKr").isEqualTo(getValueOfTable);
        System.out.println("7q9E0NKr");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Брат")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreeY1mQPKVz() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreeY1mQPKVz)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("Y1mQPKVz").isEqualTo(getValueOfTable);
        System.out.println("Y1mQPKVz");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Дедушка")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreeLnxmURg4() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreeLnxmURg4)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("LnxmURg4").isEqualTo(getValueOfTable);
        System.out.println("LnxmURg4");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Дочь")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreelR4v6uLT() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreelR4v6uLT)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("lR4v6uLT").isEqualTo(getValueOfTable);
        System.out.println("lR4v6uLT");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Друг/подруга")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreevDPgw1Q6() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreevDPgw1Q6)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("vDPgw1Q6").isEqualTo(getValueOfTable);
        System.out.println("vDPgw1Q6");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Другой родственник")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreeC7ZMgbyc() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreeC7ZMgbyc)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("C7ZMgbyc").isEqualTo(getValueOfTable);
        System.out.println("C7ZMgbyc");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Клиент")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreeOVOxPkpx() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreeOVOxPkpx)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("OVOxPkpx").isEqualTo(getValueOfTable);
        System.out.println("OVOxPkpx");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Коллега")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreerDzqPVJr() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreerDzqPVJr)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("rDzqPVJr").isEqualTo(getValueOfTable);
        System.out.println("rDzqPVJr");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Мать")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreexKraP9DQ() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreexKraP9DQ)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("xKraP9DQ").isEqualTo(getValueOfTable);
        System.out.println("xKraP9DQ");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Остальные")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegree0LilZJnc() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegree0LilZJnc)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("0LilZJnc").isEqualTo(getValueOfTable);
        System.out.println("0LilZJnc");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Отец")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreeekYxqj5U() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreeekYxqj5U)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("ekYxqj5U").isEqualTo(getValueOfTable);
        System.out.println("ekYxqj5U");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Сын")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegree81dEVcZS() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegree81dEVcZS)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("81dEVcZS").isEqualTo(getValueOfTable);
        System.out.println("81dEVcZS");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Сестра")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreesDTKdM7Z() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreesDTKdM7Z)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("sDTKdM7Z").isEqualTo(getValueOfTable);
        System.out.println("sDTKdM7Z");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Внук")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreemtsgrandchild() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreemtsgrandchild)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsgrandchild").isEqualTo(getValueOfTable);
        System.out.println("mtsgrandchild");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Внучка")
    @Description("Отправляем валидный Json.")
    public void sendRelationDegreemtsgrandchild2() throws IOException, JSONException, SQLException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendRelationDegreemtsgrandchild2)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");

        getValueOfTable = getValueOfTable("select " + getRelationDegreeBD() + " from " + getTableProfileClient() + " where " + getIblockElementIdBD() + " = " + getCustomerProfileIOfSQLRequest());
        assertThat("mtsgrandchild2").isEqualTo(getValueOfTable);
        System.out.println("mtsgrandchild2");
        System.out.println(getValueOfTable);
    }

    @Test(dependsOnMethods = "sendStep3")
    @Story("Отправка и проверка Кем приходится контактное лицо Внучка")
    @Description("Отправляем валидный Json.")
    public void sendFullProfileWithTwoConact() throws IOException, JSONException {
        send = BasePath + "step3/save&token=" + getTokenOfFile() + jsonOrderID + getIdOrderOfFile();
        Response response =
                expect()
                        .statusCode(200)
                        .given()
                        .header("content-type", JSON)
                        .header("cache-control", cachControl)
                        .cookie(phpSessId, getTokenOfFile())
                        .contentType(ContentType.JSON)
                        .log().all()
                        .body(sendFullProfileWithTwoConact)
                        .log().ifValidationFails()
                        .post(send);
        responseBody = response.getBody().asString();
        System.out.println(responseBody);
        jsonObject = new Gson().fromJson(responseBody, JsonObject.class);
        String navigated = jsonObject.get("navigated").getAsString();
        assertThat(navigated).isEqualTo("-1");
    }
}