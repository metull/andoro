package CheckProfile.GeneralData;

import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static CheckProfile.GeneralData.Data.randomPhone;
import static CheckProfile.GeneralData.SetterAndGetter.*;
import static CheckProfile.GeneralData.SqlRequest.getValueOfTable;

public class AllParameters {

    public static class EndPoints {

        public static String number = randomPhone(10);
        public static String numberOffline = randomPhone(18);
        public static JsonObject jsonObject;
        public static LocalDate localDateTime;
        public static String valueTrue = "true";
        public static String valueFalse = "false";
        public static String phpSessId = "PHPSESSID=";
        public static String responseBody;
        public static String result;
        public static String date;
        public static String send;
        public static String getPhpSessId = "PHPSESSID=hibkgq6oommu9k411849nn0nb7;";
        public static String zero = ".0000";
        public static String get;
        public static String getValueOfTable;
        public static String message;
        public static String englishAlphabet = "english";
        public static String russiaAlphabet = "ффывва";
        public static String jsonOrderID = "&json=Y&order_id=";
        public static String BasePath = "https://lk-test.direct-credit.ru/api/widget.php?action=";
        public static String createNewOrder = "http://test.direct-credit.ru/soap/service/ozon/index.php";
        public static String createOfflineOrder = "https://lk-test.direct-credit.ru/order_new/?action=cart/save&json=Y";
        public static String getSmsCode = "https://lk-test.direct-credit.ru/api/widget.php?phone_mobile=(996)%20960-2297&no_check_count=false&ad_subscribe=true&sms_mode=first&form=%5Bobject%20Object%5D&action=sms/send&token=&json=Y&order_id=";
        public static String type = "text/xml";
        public static String cachControl = "no-cache";
        public static String JSON = "application/json";
        public static String authorization = "Basic T3pvbjFvbmxpbmU6Nk14aU9vV29tdFlQQ3NqbA==";
        public static String username = "dc_bitrix";
        public static String password = "a90~q~u%@PXwA6M#";
        public static final String url = "jdbc:mysql://localhost:6033/dc_bitrix?autoReconnect=true&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC";

        public static String getCustomerProfileIOfSQLRequest() throws SQLException, IOException {
            String customerProfileID = getValueOfTable("select " + getCustomerProfileIdBD() + " from " + tableDcOrder + " where " + getOrderNumber() + " = \"numberOrder" + getNumberOrderOfFile() + "\";");
            return customerProfileID;
        }

        public static String getTokenOfFile() throws IOException {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("token.txt")));
            String token = bufferedReader.readLine();
            return token;
        }

        public static String getIdOrderOfFile() throws IOException {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("idOrder.txt")));
            String id = bufferedReader.readLine();
            return id;
        }

        public static String getNumberOfflineOrderOfFile() throws IOException {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("numberOfflineOrder.txt")));
            String id = bufferedReader.readLine();
            return id;
        }

        public static String getNumberOrderOfFile() throws IOException {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("numberOrder.txt")));
            String number = bufferedReader.readLine();
            return number;
        }

        public static String getNowDate() {
            Date today = new Date();
            SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd.MM.yyyy");
            date = DATE_FORMAT.format(today);
            return date;
        }

        public static String formateDateYyyMmDd() {
            Date needDate = new Date();
            SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy.MM.dd");
            date = DATE_FORMAT.format(needDate);
            return date;
        }

        public static String getDate100YearsLast() {
            localDateTime = LocalDate.now().minusYears(100);
            date = localDateTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            return date;
        }

        public static String getDate100YearAnd1dayLast() {
            localDateTime = LocalDate.now().minusYears(100).minusDays(1);
            date = localDateTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            return date;
        }

        public static String getDate18YearsLastAnd1Day() {
            localDateTime = LocalDate.now().minusYears(18).plusDays(1);
            date = localDateTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            return date;
        }

        public static String getDate18YearsLast() {
            localDateTime = LocalDate.now().minusYears(18);
            date = localDateTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            return date;
        }

        public static String getDateTomorrow() {
            localDateTime = LocalDate.now().plusDays(1);
            date = localDateTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            return date;
        }

    }
}

